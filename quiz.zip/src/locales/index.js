import kz from './kz.json';
import ru from './ru.json';
import en from './en.json';

export default{ kz, ru, en };