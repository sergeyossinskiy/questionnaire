<template>
  <p>Упс...</p>
  <router-view/>
</template>

<style lang="scss">

</style>