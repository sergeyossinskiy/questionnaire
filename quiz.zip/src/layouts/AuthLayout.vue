<template>
    <div class="p-grid app-layout">
        <div class="p-col-12">
            <nav class="nav">
                <Button icon="pi pi-home" class="p-button-raised p-button-rounded" @click="toHome"/>
                <!-- <router-link to="/home">Home</router-link>  -->
            </nav>
        </div> 
        <div class="p-col-12 p-md-8 p-md-offset-2">
            <router-view/>
        </div>        
    </div>
</template>

<script>
import Button from 'primevue/button';

export default {
    name: 'AuthLayout',
    components: {
        Button
    }    
}
</script>

<style lang="scss">
    
</style>