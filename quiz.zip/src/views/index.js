export { default as Home } from './Home.vue';
export { default as About } from './About.vue';
export { default as Profile } from './Profile.vue';