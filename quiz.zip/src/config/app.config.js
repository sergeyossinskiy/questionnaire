export const AppConfig = {
    appName: 'Qiuz',
    appSubTitle: 'by Means'
};