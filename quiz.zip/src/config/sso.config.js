export const SSOConfig = {
    service: 'http://means.kgu.kz/sso/services',
    api: 'http://means.kgu.kz/api/sso/services'
};