export default class AvaGuard{
    
    constructor() {}

    canEnter(to, from){
        return;//return { name: 'Login' }; 
    }
}